Option Explicit

' CATIA V5R21 standalone advanced-fixture repair generator v1.0.3.
'
' Usage:
'   cscript //nologo generate_one_advanced_fixture.vbs <fixture-dir> <case> [guided]
'
' Cases:
'   fillet | chamfer | shaft_groove | rib_slot | shell_thickness |
'   pattern | boolean | gsd_analytic | pressure
'
' Safety:
'   1. Builds and reopens a temporary CATPart first.
'   2. Replaces the requested fixture only after verification succeeds.
'   3. Copies an existing fixture into repair_backups before replacement.
'   4. Never touches the core fixtures.
'   5. Supports --syntax-check without starting CATIA.

Const CAT_TANGENCY_FILLET = 1
' CATIA enums are zero based.  These values are deliberately explicit because
' Windows Script Host does not import CATIA type-library enum symbols.
Const CAT_TANGENCY_CHAMFER = 0
Const CAT_LENGTH_ANGLE_CHAMFER = 1
Const CAT_NO_REVERSE_CHAMFER = 0

Dim fso, outputDir, caseName, guidedMode
Dim catia, cfg, ownsCatia, doc, ledger, repairLedger
Dim fileName, finalPath, tempPath, expectedNames, runtimeName

Set fso = CreateObject("Scripting.FileSystemObject")
Set catia = Nothing
Set cfg = Nothing
Set doc = Nothing
Set ledger = Nothing
Set repairLedger = Nothing
ownsCatia = False

If WScript.Arguments.Count = 1 Then
  If LCase(Trim(WScript.Arguments(0))) = "--syntax-check" Then
    WScript.Echo "[SYNTAX-OK] generate_one_advanced_fixture.vbs"
    WScript.Quit 0
  End If
End If

If WScript.Arguments.Count < 2 Or WScript.Arguments.Count > 3 Then
  WScript.Echo "Usage: cscript //nologo generate_one_advanced_fixture.vbs <fixture-dir> <case> [guided]"
  WScript.Quit 2
End If

outputDir = fso.GetAbsolutePathName(WScript.Arguments(0))
caseName = LCase(Trim(WScript.Arguments(1)))
guidedMode = False
If WScript.Arguments.Count = 3 Then guidedMode = (LCase(Trim(WScript.Arguments(2))) = "guided")

EnsureFolder outputDir
ResolveCase caseName, fileName, expectedNames
finalPath = fso.BuildPath(outputDir, fileName)
tempPath = fso.BuildPath(outputDir, "__repair_tmp_" & fileName)
DeleteIfExists tempPath

Set ledger = fso.OpenTextFile(fso.BuildPath(outputDir, "generation_ledger.tsv"), 8, True, 0)
Set repairLedger = fso.OpenTextFile(fso.BuildPath(outputDir, "advanced_repair_ledger.tsv"), 8, True, 0)

On Error Resume Next
Err.Clear
Set catia = GetObject(, "CATIA.Application")
If Err.Number <> 0 Or catia Is Nothing Then
  Err.Clear
  Set catia = CreateObject("CATIA.Application")
  RequireSuccess "CreateObject(CATIA.Application)"
  ownsCatia = True
End If

catia.Visible = True
Err.Clear
Set cfg = catia.SystemConfiguration
RequireSuccess "Read CATIA SystemConfiguration"
If cfg.Version <> 5 Or cfg.Release <> 21 Then
  FailCase "Expected CATIA V5R21 but found V" & cfg.Version & "R" & cfg.Release, 9003, 3
End If
runtimeName = "V" & cfg.Version & "R" & cfg.Release & "SP" & cfg.ServicePack

WScript.Echo "[BUILD] " & fileName & "  mode=" & ModeText()
Err.Clear
Set doc = catia.Documents.Add("Part")
RequireSuccess "Documents.Add(Part)"
doc.Activate
RequireSuccess "Activate new Part"

Select Case caseName
  Case "fillet": BuildFillet doc
  Case "chamfer": BuildChamfer doc
  Case "shaft_groove": BuildShaftGroove doc
  Case "rib_slot": BuildRibSlot doc
  Case "shell_thickness": BuildShellThickness doc
  Case "pattern": BuildPattern doc
  Case "boolean": BuildBoolean doc
  Case "gsd_analytic": BuildGsdAnalytic doc
  Case "pressure": BuildPressure doc
End Select

Err.Clear
doc.Part.Update
RequireSuccess "Final Part.Update"
VerifyNames doc, expectedNames, "in-memory final update"
If caseName <> "gsd_analytic" Then AssertPositiveVolume doc, "in-memory fixture"

Err.Clear
doc.SaveAs tempPath
RequireSuccess "SaveAs temporary CATPart"
Err.Clear
doc.Close
RequireSuccess "Close temporary CATPart"
Set doc = Nothing

WScript.Echo "[VERIFY] close/reopen and native history"
Err.Clear
Set doc = catia.Documents.Open(tempPath)
RequireSuccess "Reopen temporary CATPart"
Err.Clear
doc.Part.Update
RequireSuccess "Update reopened CATPart"
VerifyNames doc, expectedNames, "after close/reopen"
If caseName <> "gsd_analytic" Then AssertPositiveVolume doc, "reopened fixture"
Err.Clear
doc.Close
RequireSuccess "Close verified CATPart"
Set doc = Nothing

BackupExisting finalPath
Err.Clear
fso.CopyFile tempPath, finalPath, True
RequireSuccess "Publish verified CATPart"
DeleteIfExists tempPath

WriteResult "generated", "standalone repair; close/reopen verified; expected history: " & Join(expectedNames, ",")
WScript.Echo "[GENERATED] " & finalPath
WScript.Echo "[DONE] Existing file was replaced only after verification; backup is under repair_backups when applicable."
Cleanup 0
WScript.Quit 0

Sub ResolveCase(ByVal requested, ByRef resolvedFile, ByRef names)
  Select Case requested
    Case "fillet"
      resolvedFile = "pd_fillet_constant.CATPart"
      names = Array("Pad_Fillet_Base", "Fillet_Constant_R5")
    Case "chamfer"
      resolvedFile = "pd_chamfer_variants.CATPart"
      names = Array("Pad_Chamfer_Base", "Chamfer_LengthAngle")
    Case "shaft_groove"
      resolvedFile = "pd_shaft_groove.CATPart"
      names = Array("Shaft_Full360", "Groove_Annular360")
    Case "rib_slot"
      resolvedFile = "pd_rib_slot.CATPart"
      names = Array("Rib_Straight", "Slot_Straight")
    Case "shell_thickness"
      resolvedFile = "pd_shell_thickness.CATPart"
      names = Array("Pad_Shell_Base", "Shell_3mm", "Thickness_Local1mm")
    Case "pattern"
      resolvedFile = "pd_patterns.CATPart"
      names = Array("Pad_Pattern_Base", "Pad_Pattern_Seed", "RectangularPattern_3x2")
    Case "boolean"
      resolvedFile = "pd_multibody_booleans.CATPart"
      names = Array("Boolean_Add", "Boolean_Remove", "Boolean_Assemble", "Boolean_Intersect")
    Case "gsd_analytic"
      resolvedFile = "gsd_analytic_elements.CATPart"
      names = Array("Point_Origin", "Point_End", "Line_PointPoint", "Plane_Offset25", "AxisSystem_Test")
    Case "pressure"
      resolvedFile = "pressure_pad_pocket_fillet_chamfer.CATPart"
      names = Array("Pad_Pressure", "Pocket_Pressure", "Fillet_Pressure", "Chamfer_Pressure")
    Case Else
      WScript.Echo "[ERROR] Unknown case: " & requested
      WScript.Echo "Allowed: fillet chamfer shaft_groove rib_slot shell_thickness pattern boolean gsd_analytic pressure"
      WScript.Quit 2
  End Select
End Sub

Sub BuildFillet(ByVal partDoc)
  Dim part, body, planeRef, sketch, pad, edgeBoundary, fillet
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set planeRef = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  RequireSuccess "Reference PlaneXY"
  Set sketch = RectSketch(body, planeRef, "Sketch_Fillet_Base", -45, -30, 45, 30)
  Set pad = part.ShapeFactory.AddNewPad(sketch, 24)
  RequireSuccess "Create Pad_Fillet_Base"
  pad.Name = "Pad_Fillet_Base"
  part.UpdateObject pad
  RequireSuccess "Update Pad_Fillet_Base"
  Set edgeBoundary = TopologyBoundary(partDoc, "Edge", pad, "Select one outside edge for R5 fillet")
  Set fillet = Nothing
  Err.Clear
  ' The R21 Automation examples pass the TriDimFeatEdge boundary object
  ' directly.  Do not replace it with SelectedElement.Reference.
  Set fillet = part.ShapeFactory.AddNewEdgeFilletWithConstantRadius(edgeBoundary, CAT_TANGENCY_FILLET, 5)
  If Err.Number <> 0 Or fillet Is Nothing Then
    Err.Clear
    Set fillet = part.ShapeFactory.AddNewSolidEdgeFilletWithConstantRadius(edgeBoundary, CAT_TANGENCY_FILLET, 5)
  End If
  partDoc.Selection.Clear
  RequireObject fillet, "constant-radius fillet factory result"
  RequireSuccess "Create constant-radius solid edge fillet"
  CommitNamedFeature part, fillet, "Fillet_Constant_R5", "constant-radius fillet"
End Sub

Sub BuildChamfer(ByVal partDoc)
  Dim part, body, planeRef, sketch, pad, edgeBoundary, chamfer
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set planeRef = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  RequireSuccess "Reference PlaneXY"
  Set sketch = RectSketch(body, planeRef, "Sketch_Chamfer_Base", -45, -30, 45, 30)
  Set pad = part.ShapeFactory.AddNewPad(sketch, 24)
  RequireSuccess "Create Pad_Chamfer_Base"
  pad.Name = "Pad_Chamfer_Base"
  part.UpdateObject pad
  RequireSuccess "Update Pad_Chamfer_Base"
  Set edgeBoundary = TopologyBoundary(partDoc, "Edge", pad, "Select one outside edge for 5mm x 45deg chamfer")
  Set chamfer = part.ShapeFactory.AddNewChamfer(edgeBoundary, CAT_TANGENCY_CHAMFER, CAT_LENGTH_ANGLE_CHAMFER, CAT_NO_REVERSE_CHAMFER, 5, 45)
  partDoc.Selection.Clear
  RequireObject chamfer, "length-angle chamfer factory result"
  RequireSuccess "Create length-angle chamfer"
  CommitNamedFeature part, chamfer, "Chamfer_LengthAngle", "length-angle chamfer"
End Sub

Sub BuildShaftGroove(ByVal partDoc)
  Dim part, body, planeRef, sketch, f2d, shaft, axisLine
  Dim grooveSketch, groove, grooveAxisLine, angle1, angle2
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set planeRef = part.CreateReferenceFromObject(part.OriginElements.PlaneZX)
  RequireSuccess "Reference PlaneZX"

  Set sketch = body.Sketches.Add(planeRef)
  RequireSuccess "Create Sketch_Shaft_Profile"
  sketch.Name = "Sketch_Shaft_Profile"
  Set f2d = sketch.OpenEdition()
  RequireSuccess "Open shaft sketch"
  f2d.CreateLine 10, 0, 35, 0
  f2d.CreateLine 35, 0, 35, 25
  f2d.CreateLine 35, 25, 10, 25
  f2d.CreateLine 10, 25, 10, 0
  Set axisLine = f2d.CreateLine(0, -10, 0, 35)
  Set sketch.CenterLine = axisLine
  RequireSuccess "Define shaft sketch CenterLine"
  sketch.CloseEdition
  RequireSuccess "Close shaft sketch"
  Set shaft = part.ShapeFactory.AddNewShaft(sketch)
  RequireObject shaft, "shaft factory result"
  RequireSuccess "Create Shaft from sketch"
  Set angle1 = shaft.FirstAngle: angle1.Value = 360
  Set angle2 = shaft.SecondAngle: angle2.Value = 0
  CommitNamedFeature part, shaft, "Shaft_Full360", "full 360-degree shaft"
  AssertPositiveVolume partDoc, "after Shaft_Full360"

  Set grooveSketch = body.Sketches.Add(planeRef)
  RequireSuccess "Create Sketch_Groove_Profile"
  grooveSketch.Name = "Sketch_Groove_Profile"
  Set f2d = grooveSketch.OpenEdition()
  f2d.CreateLine 30, 8, 38, 8
  f2d.CreateLine 38, 8, 38, 15
  f2d.CreateLine 38, 15, 30, 15
  f2d.CreateLine 30, 15, 30, 8
  Set grooveAxisLine = f2d.CreateLine(0, -10, 0, 35)
  Set grooveSketch.CenterLine = grooveAxisLine
  RequireSuccess "Define groove sketch CenterLine"
  grooveSketch.CloseEdition
  RequireSuccess "Close groove sketch"
  Set groove = part.ShapeFactory.AddNewGroove(grooveSketch)
  RequireObject groove, "groove factory result"
  RequireSuccess "Create Groove from sketch"
  Set angle1 = groove.FirstAngle: angle1.Value = 360
  Set angle2 = groove.SecondAngle: angle2.Value = 0
  CommitNamedFeature part, groove, "Groove_Annular360", "annular 360-degree groove"
  AssertPositiveVolume partDoc, "after Groove_Annular360"
End Sub

Sub BuildRibSlot(ByVal partDoc)
  Dim part, body, refXY, refYZ, profile, center, f2d, rib
  Dim slotProfile, slotCenter, slot
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set refXY = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  Set refYZ = part.CreateReferenceFromObject(part.OriginElements.PlaneYZ)
  RequireSuccess "Resolve rib/slot planes"

  Set profile = body.Sketches.Add(refYZ): profile.Name = "Sketch_Rib_Profile"
  Set f2d = profile.OpenEdition(): f2d.CreateClosedCircle 0, 0, 5: profile.CloseEdition
  RequireSuccess "Create rib profile"
  Set center = body.Sketches.Add(refXY): center.Name = "Sketch_Rib_Center"
  Set f2d = center.OpenEdition(): f2d.CreateLine 0, 0, 60, 0: center.CloseEdition
  RequireSuccess "Create rib center curve"
  Set rib = part.ShapeFactory.AddNewRib(profile, center)
  RequireSuccess "Create Rib_Straight"
  rib.Name = "Rib_Straight"
  part.UpdateObject rib
  RequireSuccess "Update Rib_Straight"

  Set slotProfile = body.Sketches.Add(refYZ): slotProfile.Name = "Sketch_Slot_Profile"
  Set f2d = slotProfile.OpenEdition(): f2d.CreateClosedCircle 0, 0, 2: slotProfile.CloseEdition
  RequireSuccess "Create slot profile"
  Set slotCenter = body.Sketches.Add(refXY): slotCenter.Name = "Sketch_Slot_Center"
  Set f2d = slotCenter.OpenEdition(): f2d.CreateLine 0, 0, 60, 0: slotCenter.CloseEdition
  RequireSuccess "Create slot center curve"
  Set slot = part.ShapeFactory.AddNewSlot(slotProfile, slotCenter)
  RequireSuccess "Create Slot_Straight"
  slot.Name = "Slot_Straight"
  part.UpdateObject slot
  RequireSuccess "Update Slot_Straight"
End Sub

Sub BuildShellThickness(ByVal partDoc)
  Dim part, body, planeRef, sketch, pad, faceBoundary, shell
  Dim thicknessBody, thicknessSketch, thicknessPad, thicknessBoundary, thickness
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set planeRef = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  Set sketch = RectSketch(body, planeRef, "Sketch_Shell_Base", -45, -35, 45, 35)
  Set pad = part.ShapeFactory.AddNewPad(sketch, 35)
  RequireSuccess "Create Pad_Shell_Base"
  pad.Name = "Pad_Shell_Base"
  part.UpdateObject pad
  RequireSuccess "Update Pad_Shell_Base"
  Set faceBoundary = TopologyBoundary(partDoc, "Face", pad, "Select one large face to remove for the 3mm shell")
  Set shell = part.ShapeFactory.AddNewShell(faceBoundary, 3, 0)
  partDoc.Selection.Clear
  RequireObject shell, "shell factory result"
  RequireSuccess "Create Shell_3mm"
  CommitNamedFeature part, shell, "Shell_3mm", "3mm shell"

  ' Keep the local-thickness probe in a second native Body.  Applying a
  ' Thickness immediately after Shell makes the result depend on which wall
  ' R21 returned first; a separate solid still exercises the native decoder
  ' while remaining deterministic.
  Set thicknessBody = part.Bodies.Add()
  thicknessBody.Name = "Thickness_Test_Body"
  part.InWorkObject = thicknessBody
  Set thicknessSketch = RectSketch(thicknessBody, planeRef, "Sketch_Thickness_Base", 70, -25, 120, 25)
  Set thicknessPad = part.ShapeFactory.AddNewPad(thicknessSketch, 18)
  RequireObject thicknessPad, "thickness carrier pad result"
  thicknessPad.Name = "Pad_Thickness_Base"
  part.UpdateObject thicknessPad
  RequireSuccess "Update Pad_Thickness_Base"
  Set thicknessBoundary = TopologyBoundary(partDoc, "Face", thicknessPad, "Select one face for local 1mm thickness")
  Set thickness = part.ShapeFactory.AddNewThickness(thicknessBoundary, 1)
  partDoc.Selection.Clear
  RequireObject thickness, "local thickness factory result"
  RequireSuccess "Create local Thickness"
  CommitNamedFeature part, thickness, "Thickness_Local1mm", "local 1mm thickness"
End Sub

Sub BuildPattern(ByVal partDoc)
  Dim part, body, refXY, sketch, pad, seedSketch, seed, dir1, dir2, pattern
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set refXY = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  Set sketch = RectSketch(body, refXY, "Sketch_Pattern_Base", -70, -45, 70, 45)
  Set pad = part.ShapeFactory.AddNewPad(sketch, 12)
  RequireSuccess "Create Pad_Pattern_Base"
  pad.Name = "Pad_Pattern_Base"
  part.UpdateObject pad
  RequireSuccess "Update Pad_Pattern_Base"
  Set seedSketch = CircleSketch(body, refXY, "Sketch_Pattern_Seed", -45, -20, 6)
  Set seed = part.ShapeFactory.AddNewPad(seedSketch, 24)
  RequireSuccess "Create Pad_Pattern_Seed"
  seed.Name = "Pad_Pattern_Seed"
  part.UpdateObject seed
  RequireSuccess "Update Pad_Pattern_Seed"
  Set dir1 = part.CreateReferenceFromObject(part.OriginElements.PlaneYZ)
  Set dir2 = part.CreateReferenceFromObject(part.OriginElements.PlaneZX)
  RequireSuccess "Resolve rectangular-pattern directions"
  Set pattern = part.ShapeFactory.AddNewRectPattern(seed, 3, 2, 25, 25, 1, 1, dir1, dir2, False, False, 0)
  RequireSuccess "Create RectangularPattern_3x2"
  pattern.Name = "RectangularPattern_3x2"
  part.UpdateObject pattern
  RequireSuccess "Update RectangularPattern_3x2"
End Sub

Sub BuildBoolean(ByVal partDoc)
  Dim part, targetBody, toolBody, refXY, feature
  Set part = partDoc.Part
  Set refXY = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  RequireSuccess "Reference PlaneXY for Boolean fixture"

  ' Use one independent result Body per Boolean kind.  Chaining Add, Remove,
  ' Assemble and Intersect on the same current result made R21's last update
  ' collapse the complete fixture to an empty body even though intermediate
  ' Product.Analyze values were stale and positive.
  Set targetBody = MainBody(part)
  AddBlockToBody part, targetBody, refXY, "Sketch_Boolean_Add_Target", -45, -30, 45, 30, 20, "Pad_Boolean_Add_Target"
  Set toolBody = AddToolBody(part, refXY, "ToolBody_Add", "Sketch_Tool_Add", 25, 0, 18, 30)
  part.InWorkObject = targetBody
  Set feature = part.ShapeFactory.AddNewAdd(toolBody): RequireSuccess "Create Boolean_Add"
  RequireObject feature, "Boolean_Add factory result"
  CommitNamedFeature part, feature, "Boolean_Add", "boolean add"
  AssertBodyPositiveVolume partDoc, targetBody, "after Boolean_Add"

  Set targetBody = part.Bodies.Add(): targetBody.Name = "Boolean_Remove_Result"
  AddBlockToBody part, targetBody, refXY, "Sketch_Boolean_Remove_Target", 75, -30, 165, 30, 20, "Pad_Boolean_Remove_Target"
  Set toolBody = AddToolBody(part, refXY, "ToolBody_Remove", "Sketch_Tool_Remove", 120, 0, 12, 30)
  part.InWorkObject = targetBody
  Set feature = part.ShapeFactory.AddNewRemove(toolBody): RequireSuccess "Create Boolean_Remove"
  RequireObject feature, "Boolean_Remove factory result"
  CommitNamedFeature part, feature, "Boolean_Remove", "boolean remove"
  AssertBodyPositiveVolume partDoc, targetBody, "after Boolean_Remove"

  Set targetBody = part.Bodies.Add(): targetBody.Name = "Boolean_Assemble_Result"
  AddBlockToBody part, targetBody, refXY, "Sketch_Boolean_Assemble_Target", -165, -30, -75, 30, 20, "Pad_Boolean_Assemble_Target"
  Set toolBody = AddToolBody(part, refXY, "ToolBody_Assemble", "Sketch_Tool_Assemble", -90, 0, 14, 30)
  part.InWorkObject = targetBody
  Set feature = part.ShapeFactory.AddNewAssemble(toolBody): RequireSuccess "Create Boolean_Assemble"
  RequireObject feature, "Boolean_Assemble factory result"
  CommitNamedFeature part, feature, "Boolean_Assemble", "boolean assemble"
  AssertBodyPositiveVolume partDoc, targetBody, "after Boolean_Assemble"

  Set targetBody = part.Bodies.Add(): targetBody.Name = "Boolean_Intersect_Result"
  AddBlockToBody part, targetBody, refXY, "Sketch_Boolean_Intersect_Target", -45, 70, 45, 130, 20, "Pad_Boolean_Intersect_Target"
  Set toolBody = AddToolBody(part, refXY, "ToolBody_Intersect", "Sketch_Tool_Intersect", 0, 100, 22, 30)
  part.InWorkObject = targetBody
  Set feature = part.ShapeFactory.AddNewIntersect(toolBody): RequireSuccess "Create Boolean_Intersect"
  RequireObject feature, "Boolean_Intersect factory result"
  CommitNamedFeature part, feature, "Boolean_Intersect", "boolean intersect"
  AssertBodyPositiveVolume partDoc, targetBody, "after Boolean_Intersect"
End Sub

Sub AddBlockToBody(ByVal part, ByVal body, ByVal planeRef, ByVal sketchName, ByVal x1, ByVal y1, ByVal x2, ByVal y2, ByVal height, ByVal padName)
  Dim sketch, pad
  part.InWorkObject = body
  Set sketch = RectSketch(body, planeRef, sketchName, x1, y1, x2, y2)
  Set pad = part.ShapeFactory.AddNewPad(sketch, height)
  RequireObject pad, padName & " factory result"
  RequireSuccess "Create " & padName
  pad.Name = padName
  part.UpdateObject pad
  RequireSuccess "Update " & padName
  part.Update
  RequireSuccess "Part.Update " & padName
End Sub

Function AddToolBody(ByVal part, ByVal planeRef, ByVal bodyName, ByVal sketchName, ByVal x, ByVal y, ByVal radius, ByVal height)
  Dim body, sketch, pad
  Set body = part.Bodies.Add(): body.Name = bodyName: part.InWorkObject = body
  Set sketch = CircleSketch(body, planeRef, sketchName, x, y, radius)
  Set pad = part.ShapeFactory.AddNewPad(sketch, height)
  RequireObject pad, bodyName & " pad factory result"
  RequireSuccess "Create pad in " & bodyName
  pad.Name = "Pad_" & bodyName
  part.UpdateObject pad
  RequireSuccess "Update " & bodyName
  part.Update
  RequireSuccess "Part.Update " & bodyName
  Set AddToolBody = body
End Function

Sub BuildGsdAnalytic(ByVal partDoc)
  Dim part, hybridBody, hsf, p1, p2, line, plane, axis
  Set part = partDoc.Part
  Set hybridBody = part.HybridBodies.Add(): hybridBody.Name = "GSD_Analytic"
  Set hsf = part.HybridShapeFactory
  Set p1 = hsf.AddNewPointCoord(0, 0, 0): p1.Name = "Point_Origin": hybridBody.AppendHybridShape p1
  Set p2 = hsf.AddNewPointCoord(50, 20, 30): p2.Name = "Point_End": hybridBody.AppendHybridShape p2
  RequireSuccess "Create GSD points"
  Set line = hsf.AddNewLinePtPt(part.CreateReferenceFromObject(p1), part.CreateReferenceFromObject(p2))
  RequireSuccess "Create GSD point-point line"
  line.Name = "Line_PointPoint": hybridBody.AppendHybridShape line
  Set plane = hsf.AddNewPlaneOffset(part.CreateReferenceFromObject(part.OriginElements.PlaneXY), 25, False)
  RequireSuccess "Create GSD offset plane"
  plane.Name = "Plane_Offset25": hybridBody.AppendHybridShape plane
  Set axis = part.AxisSystems.Add(): axis.Name = "AxisSystem_Test"
  RequireSuccess "Create AxisSystem_Test"
  part.Update
  RequireSuccess "Update GSD analytic part"
End Sub

Sub BuildPressure(ByVal partDoc)
  Dim part, body, refXY, sketch, pad, pocketSketch, pocket
  Dim edgeBoundary, fillet, chamferBoundary, chamfer
  Set part = partDoc.Part
  Set body = MainBody(part)
  Set refXY = part.CreateReferenceFromObject(part.OriginElements.PlaneXY)
  Set sketch = RectSketch(body, refXY, "Sketch_Pressure_Base", -55, -40, 55, 40)
  Set pad = part.ShapeFactory.AddNewPad(sketch, 25): RequireSuccess "Create Pad_Pressure"
  pad.Name = "Pad_Pressure": part.UpdateObject pad: RequireSuccess "Update Pad_Pressure"
  Set pocketSketch = CircleSketch(body, refXY, "Sketch_Pressure_Pocket", 0, 0, 15)
  Set pocket = part.ShapeFactory.AddNewPocket(pocketSketch, 10): RequireSuccess "Create Pocket_Pressure"
  pocket.Name = "Pocket_Pressure": pocket.DirectionOrientation = 0
  part.UpdateObject pocket: RequireSuccess "Update Pocket_Pressure"
  Set edgeBoundary = TopologyBoundary(partDoc, "Edge", pocket, "Select an outside edge for the pressure-part R4 fillet")
  Set fillet = Nothing
  Err.Clear
  Set fillet = part.ShapeFactory.AddNewEdgeFilletWithConstantRadius(edgeBoundary, CAT_TANGENCY_FILLET, 4)
  If Err.Number <> 0 Or fillet Is Nothing Then
    Err.Clear
    Set fillet = part.ShapeFactory.AddNewSolidEdgeFilletWithConstantRadius(edgeBoundary, CAT_TANGENCY_FILLET, 4)
  End If
  partDoc.Selection.Clear
  RequireObject fillet, "pressure fillet factory result"
  RequireSuccess "Create Fillet_Pressure"
  CommitNamedFeature part, fillet, "Fillet_Pressure", "pressure-part fillet"
  Set chamferBoundary = TopologyBoundary(partDoc, "Edge", fillet, "Select a different straight edge for the pressure-part chamfer")
  Set chamfer = part.ShapeFactory.AddNewChamfer(chamferBoundary, CAT_TANGENCY_CHAMFER, CAT_LENGTH_ANGLE_CHAMFER, CAT_NO_REVERSE_CHAMFER, 3, 45)
  partDoc.Selection.Clear
  RequireObject chamfer, "pressure chamfer factory result"
  RequireSuccess "Create Chamfer_Pressure"
  CommitNamedFeature part, chamfer, "Chamfer_Pressure", "pressure-part chamfer"
End Sub

Function TopologyBoundary(ByVal partDoc, ByVal topologyKind, ByVal supportShape, ByVal prompt)
  Dim sel, boundary, countValue, status, filters(0), query, sourceText
  Set boundary = Nothing
  Set sel = partDoc.Selection
  sel.Clear
  partDoc.Activate
  catia.Visible = True

  If Not guidedMode Then
    ' Restrict the search to the feature that owns the desired result first.
    ' This avoids accidentally taking a sketch edge or a boundary from another
    ' Body in the multi-body fixtures.
    Err.Clear
    sel.Add supportShape
    RequireSuccess "Seed feature-scoped topology search"
    query = "Topology.CAT" & topologyKind & ",sel"
    Err.Clear
    sel.Search query
    If Err.Number = 0 Then
      countValue = 0
      Err.Clear
      countValue = sel.Count2
      If Err.Number <> 0 Then Err.Clear: countValue = sel.Count
      If countValue > 0 Then
        Err.Clear
        Set boundary = sel.Item2(1).Value
        If Err.Number <> 0 Or boundary Is Nothing Then
          Err.Clear
          Set boundary = sel.Item(1).Value
        End If
        sourceText = "feature-scoped"
      End If
    End If
    Err.Clear

    ' Some R21 installations do not honor the ,sel topology scope.  Fall back
    ' to all topology only if the scoped search returned nothing.
    If boundary Is Nothing Then
      sel.Clear
      query = "Topology.CAT" & topologyKind & ",all"
      sel.Search query
      If Err.Number = 0 Then
        countValue = 0
        countValue = sel.Count2
        If Err.Number <> 0 Then Err.Clear: countValue = sel.Count
        If countValue > 0 Then
          Err.Clear
          Set boundary = sel.Item2(1).Value
          If Err.Number <> 0 Or boundary Is Nothing Then
            Err.Clear
            Set boundary = sel.Item(1).Value
          End If
          sourceText = "document-wide"
        End If
      End If
      Err.Clear
    End If
  End If

  If boundary Is Nothing Then
    sel.Clear
    If topologyKind = "Edge" Then
      filters(0) = "TriDimFeatEdge"
    Else
      filters(0) = "Face"
    End If
    WScript.Echo "[SELECT] " & prompt
    Err.Clear
    status = sel.SelectElement2(filters, prompt, False)
    RequireSuccess "Interactive " & topologyKind & " selection"
    If status <> "Normal" Then FailCase "Selection cancelled: " & prompt, 9010, 10
    Err.Clear
    Set boundary = sel.Item2(1).Value
    If Err.Number <> 0 Or boundary Is Nothing Then
      Err.Clear
      Set boundary = sel.Item(1).Value
    End If
    RequireSuccess "Read selected " & topologyKind & " boundary"
    sourceText = "interactive"
  End If
  If boundary Is Nothing Then FailCase "No usable " & topologyKind & " boundary", 9011, 10
  ' Do not clear Selection here.  CATIA Boundary objects are short-lived; the
  ' caller clears it only after the ShapeFactory method has consumed Value.
  WScript.Echo "[TOPOLOGY] " & topologyKind & " source=" & sourceText & " type=" & TypeName(boundary)
  Set TopologyBoundary = boundary
End Function

Function MainBody(ByVal part)
  Dim body
  Err.Clear
  If part.Bodies.Count = 0 Then
    Set body = part.Bodies.Add()
  Else
    Set body = part.Bodies.Item(1)
  End If
  RequireSuccess "Resolve PartBody"
  body.Name = "PartBody"
  part.InWorkObject = body
  Set MainBody = body
End Function

Function RectSketch(ByVal body, ByVal supportRef, ByVal sketchName, ByVal x1, ByVal y1, ByVal x2, ByVal y2)
  Dim sketch, f2d
  Err.Clear
  Set sketch = body.Sketches.Add(supportRef)
  RequireSuccess "Create " & sketchName
  sketch.Name = sketchName
  Set f2d = sketch.OpenEdition()
  RequireSuccess "Open " & sketchName
  f2d.CreateLine x1, y1, x2, y1
  f2d.CreateLine x2, y1, x2, y2
  f2d.CreateLine x2, y2, x1, y2
  f2d.CreateLine x1, y2, x1, y1
  sketch.CloseEdition
  RequireSuccess "Close " & sketchName
  Set RectSketch = sketch
End Function

Function CircleSketch(ByVal body, ByVal supportRef, ByVal sketchName, ByVal x, ByVal y, ByVal radius)
  Dim sketch, f2d
  Err.Clear
  Set sketch = body.Sketches.Add(supportRef)
  RequireSuccess "Create " & sketchName
  sketch.Name = sketchName
  Set f2d = sketch.OpenEdition()
  RequireSuccess "Open " & sketchName
  f2d.CreateClosedCircle x, y, radius
  sketch.CloseEdition
  RequireSuccess "Close " & sketchName
  Set CircleSketch = sketch
End Function

Sub CommitNamedFeature(ByVal part, ByVal feature, ByVal targetName, ByVal stepName)
  RequireObject feature, stepName & " object before update"
  Err.Clear
  part.UpdateObject feature
  RequireSuccess "Update " & stepName
  Err.Clear
  feature.Name = targetName
  RequireSuccess "Name " & stepName & " as " & targetName
  Err.Clear
  part.UpdateObject feature
  RequireSuccess "Re-update " & stepName
  ' Some R21 dress-up/boolean features re-apply their default label during Update.
  ' Write the user-visible name again after the final update, immediately before SaveAs.
  Err.Clear
  feature.Name = targetName
  RequireSuccess "Persist name " & targetName
  WScript.Echo "[FEATURE] " & targetName & " type=" & TypeName(feature)
End Sub

Sub VerifyNames(ByVal partDoc, ByVal names, ByVal context)
  Dim i, obj, part
  Set part = partDoc.Part
  For i = 0 To UBound(names)
    Set obj = FindHistoryObject(partDoc, CStr(names(i)))
    If obj Is Nothing Then
      DumpFeatureInventory partDoc, "missing " & CStr(names(i)) & " " & context
      FailCase "Missing expected native history object " & context & ": " & names(i), 9020, 20
    End If
    WScript.Echo "[HISTORY-OK] " & context & " " & CStr(names(i)) & " type=" & TypeName(obj)
  Next
End Sub

Function FindHistoryObject(ByVal partDoc, ByVal expectedName)
  Dim part, obj, sel, countValue, query
  Set FindHistoryObject = Nothing
  Set part = partDoc.Part
  Set obj = Nothing
  Err.Clear
  Set obj = part.FindObjectByName(expectedName)
  If Err.Number = 0 And Not obj Is Nothing Then
    Set FindHistoryObject = obj
    Exit Function
  End If

  ' FindObjectByName is inconsistent for several dress-up features in old V5.
  ' Search by the specification-tree display name as a second, independent check.
  Err.Clear
  Set sel = partDoc.Selection
  sel.Clear
  query = "Name=" & expectedName & ",all"
  sel.Search query
  If Err.Number = 0 Then
    countValue = 0
    countValue = sel.Count2
    If Err.Number <> 0 Then Err.Clear: countValue = sel.Count
    If countValue > 0 Then
      Err.Clear
      Set obj = sel.Item2(1).Value
      If Err.Number <> 0 Or obj Is Nothing Then
        Err.Clear
        Set obj = sel.Item(1).Value
      End If
    End If
  End If
  sel.Clear
  Err.Clear
  If Not obj Is Nothing Then Set FindHistoryObject = obj
End Function

Sub DumpFeatureInventory(ByVal partDoc, ByVal reason)
  Dim part, bodies, body, shapes, feature, i, j, featureName
  On Error Resume Next
  Set part = partDoc.Part
  WScript.Echo "[HISTORY-DUMP] " & reason
  Set bodies = part.Bodies
  For i = 1 To bodies.Count
    Set body = bodies.Item(i)
    WScript.Echo "[HISTORY] BODY " & body.Name & " type=" & TypeName(body)
    Set shapes = Nothing
    Err.Clear
    Set shapes = body.Shapes
    If Err.Number = 0 And Not shapes Is Nothing Then
      For j = 1 To shapes.Count
        Set feature = Nothing
        Set feature = shapes.Item(j)
        featureName = "<unreadable>"
        Err.Clear
        featureName = feature.Name
        If Err.Number <> 0 Then Err.Clear
        WScript.Echo "[HISTORY]   " & CStr(j) & " " & featureName & " type=" & TypeName(feature)
      Next
    End If
    Err.Clear
  Next
  Err.Clear
End Sub

Sub AssertPositiveVolume(ByVal partDoc, ByVal context)
  Dim volume, spaVolume, spa, bodyRef, measurable, mainResult
  volume = 0
  spaVolume = 0
  Err.Clear
  volume = partDoc.Product.Analyze.Volume
  If Err.Number <> 0 Then Err.Clear: volume = 0
  If volume > 0 Then Exit Sub

  ' Product.Analyze can report zero on an unsaved multi-body R21 document.
  ' Re-check the Part's main result with the independent SPA workbench.
  Set spa = Nothing
  Set mainResult = Nothing
  Set bodyRef = Nothing
  Set measurable = Nothing
  Err.Clear
  Set spa = partDoc.GetWorkbench("SPAWorkbench")
  Set mainResult = partDoc.Part.MainBody
  Set bodyRef = partDoc.Part.CreateReferenceFromObject(mainResult)
  Set measurable = spa.GetMeasurable(bodyRef)
  spaVolume = measurable.Volume
  If Err.Number <> 0 Then Err.Clear: spaVolume = 0
  If spaVolume > 0 Then
    WScript.Echo "[VOLUME] " & context & " Product.Analyze=0 SPA.MainBody=" & CStr(spaVolume)
    Exit Sub
  End If

  DumpFeatureInventory partDoc, "zero volume in " & context
  FailCase "No positive volume in " & context & " (Product.Analyze=" & CStr(volume) & ", SPA.MainBody=" & CStr(spaVolume) & ")", 9021, 21
End Sub

Sub AssertBodyPositiveVolume(ByVal partDoc, ByVal body, ByVal context)
  Dim spa, bodyRef, measurable, bodyVolume
  bodyVolume = 0
  Set spa = Nothing
  Set bodyRef = Nothing
  Set measurable = Nothing
  Err.Clear
  Set spa = partDoc.GetWorkbench("SPAWorkbench")
  Set bodyRef = partDoc.Part.CreateReferenceFromObject(body)
  Set measurable = spa.GetMeasurable(bodyRef)
  bodyVolume = measurable.Volume
  If Err.Number <> 0 Then Err.Clear: bodyVolume = 0
  WScript.Echo "[BODY-VOLUME] " & context & " body=" & body.Name & " volume=" & CStr(bodyVolume)
  If bodyVolume <= 0 Then
    DumpFeatureInventory partDoc, "zero body volume " & context
    FailCase "No positive result volume " & context & " body=" & body.Name, 9022, 22
  End If
End Sub

Sub BackupExisting(ByVal path)
  Dim backupRoot, backupDir, backupPath
  If Not fso.FileExists(path) Then Exit Sub
  backupRoot = fso.BuildPath(outputDir, "repair_backups")
  EnsureFolder backupRoot
  backupDir = fso.BuildPath(backupRoot, Stamp())
  EnsureFolder backupDir
  backupPath = fso.BuildPath(backupDir, fso.GetFileName(path))
  Err.Clear
  fso.CopyFile path, backupPath, True
  RequireSuccess "Backup existing fixture"
  WScript.Echo "[BACKUP] " & backupPath
End Sub

Function Stamp()
  Dim value
  value = Year(Now) & Two(Month(Now)) & Two(Day(Now)) & "_" & Two(Hour(Now)) & Two(Minute(Now)) & Two(Second(Now))
  Stamp = value
End Function

Function Two(ByVal value)
  If value < 10 Then Two = "0" & value Else Two = CStr(value)
End Function

Function ModeText()
  If guidedMode Then ModeText = "guided-selection" Else ModeText = "auto-topology-search"
End Function

Sub EnsureFolder(ByVal path)
  Dim parent
  If fso.FolderExists(path) Then Exit Sub
  parent = fso.GetParentFolderName(path)
  If Len(parent) > 0 And Not fso.FolderExists(parent) Then EnsureFolder parent
  Err.Clear
  fso.CreateFolder path
  If Err.Number <> 0 Then
    WScript.Echo "[ERROR] Cannot create folder: " & path & " 0x" & Hex(Err.Number) & " " & Err.Description
    WScript.Quit 2
  End If
End Sub

Sub DeleteIfExists(ByVal path)
  Err.Clear
  If fso.FileExists(path) Then fso.DeleteFile path, True
  Err.Clear
End Sub

Sub RequireSuccess(ByVal stepName)
  Dim errNo, errText
  If Err.Number = 0 Then Exit Sub
  errNo = Err.Number
  errText = Err.Description
  Err.Clear
  FailCase stepName & ": " & errText, errNo, 10
End Sub

Sub RequireObject(ByVal value, ByVal stepName)
  If value Is Nothing Then FailCase stepName & ": CATIA returned Nothing", 9023, 10
End Sub

Sub FailCase(ByVal message, ByVal errNo, ByVal exitCode)
  On Error Resume Next
  WScript.Echo "[BLOCKED] " & fileName & " 0x" & Hex(errNo) & " " & message
  If Len(runtimeName) = 0 Then runtimeName = "unknown"
  WriteResult "blocked", "standalone repair failed 0x" & Hex(errNo) & " " & Clean(message)
  If Not doc Is Nothing Then doc.Close
  Set doc = Nothing
  DeleteIfExists tempPath
  Cleanup exitCode
  WScript.Quit exitCode
End Sub

Sub WriteResult(ByVal status, ByVal evidence)
  On Error Resume Next
  If Not ledger Is Nothing Then
    ledger.WriteLine fileName & vbTab & status & vbTab & runtimeName & vbTab & evidence
  End If
  If Not repairLedger Is Nothing Then
    repairLedger.WriteLine Stamp() & vbTab & fileName & vbTab & status & vbTab & runtimeName & vbTab & evidence
  End If
End Sub

Function Clean(ByVal value)
  Clean = Replace(Replace(CStr(value), vbTab, " "), vbCrLf, " ")
End Function

Sub Cleanup(ByVal exitCode)
  On Error Resume Next
  If Not doc Is Nothing Then doc.Close
  Set doc = Nothing
  If Not ledger Is Nothing Then ledger.Close
  Set ledger = Nothing
  If Not repairLedger Is Nothing Then repairLedger.Close
  Set repairLedger = Nothing
  If ownsCatia And Not catia Is Nothing Then catia.Quit
  Set catia = Nothing
End Sub
